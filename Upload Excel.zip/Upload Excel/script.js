function learnMore() {
    alert("Discover how AI Innovations can help transform your business operations with cutting-edge AI solutions.");
}
